import { getDb } from "../api/queries/connection";
import { schemes } from "./schema";

const governmentSchemes = [
  {
    title: "Pradhan Mantri Jan Dhan Yojana (PMJDY)",
    content:
      "Financial inclusion program launched in August 2014. Provides universal access to banking facilities with zero-balance bank accounts, RuPay debit cards, accident insurance coverage of Rs. 2 lakh, and life insurance cover of Rs. 30,000. Over 50 crore accounts opened. Aimed at providing banking facilities to every household, especially the underprivileged. Benefits include direct benefit transfer (DBT), overdraft facility up to Rs. 10,000, and access to pension and insurance products.",
    category: "financial-inclusion" as const,
    url: "https://pmjdy.gov.in",
    metrics: {
      accounts_opened: "50+ crore",
      deposits: "Rs. 2+ lakh crore",
      insurance_cover: "Rs. 2 lakh",
    },
    eligibility:
      "Indian citizen above 10 years of age. No minimum income requirement. Primarily targets unbanked households.",
    documents:
      "Aadhaar card, Voter ID, or any officially valid document (OVD). If Aadhaar is not available, one attested photograph and signature/thumb impression required.",
    status: "active" as const,
  },
  {
    title: "Ayushman Bharat Pradhan Mantri Jan Arogya Yojana (AB-PMJAY)",
    content:
      "World's largest government-funded healthcare scheme launched in September 2018. Provides health cover of Rs. 5 lakh per family per year for secondary and tertiary care hospitalization. Covers over 12 crore poor and vulnerable families (approximately 55 crore beneficiaries). Includes pre and post hospitalization expenses, transport allowance, and covers 1,949 treatment procedures. Cashless and paperless access to services at empaneled public and private hospitals.",
    category: "healthcare" as const,
    url: "https://pmjay.gov.in",
    metrics: {
      beneficiaries: "55+ crore",
      hospitals_empaneled: "30,000+",
      treatments_covered: "1,949",
    },
    eligibility:
      "Families identified as deprived rural families and occupational categories of urban workers based on SECC 2011 data. No cap on age or family size.",
    documents:
      "PM-JAY e-card or verification through Aadhaar. No specific document required at hospital if eligible under the scheme database.",
    status: "active" as const,
  },
  {
    title: "Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)",
    content:
      "Central sector scheme launched in December 2018 to supplement financial needs of land-holding farmers. Provides income support of Rs. 6,000 per year in three equal installments of Rs. 2,000 each. Funds transferred directly to beneficiaries' bank accounts. Covers over 11 crore farmer families across India. The scheme aims to ensure dignified living for farmers and prevent them from falling into moneylender debt traps.",
    category: "agriculture" as const,
    url: "https://pmkisan.gov.in",
    metrics: {
      beneficiaries: "11+ crore",
      amount_disbursed: "Rs. 2.8+ lakh crore",
      installment: "Rs. 2,000",
    },
    eligibility:
      "All landholding farmer families with cultivable land as per land records. Small and marginal farmers as well as larger landholders are eligible.",
    documents:
      "Aadhaar card, Land ownership documents, Bank account details linked with Aadhaar.",
    status: "active" as const,
  },
  {
    title: "Pradhan Mantri Awas Yojana (PMAY)",
    content:
      "Housing for All scheme launched in June 2015. Aims to provide affordable housing to urban and rural poor by 2024. Offers interest subsidy on home loans: EWS/LIG (6.5%), MIG-I (4%), MIG-II (3%). Beneficiaries include women, scheduled castes, scheduled tribes, and other disadvantaged groups. Over 3.5 crore houses sanctioned. Credit-linked subsidy scheme (CLSS) has benefited middle-income families significantly.",
    category: "housing" as const,
    url: "https://pmaymis.gov.in",
    metrics: {
      houses_sanctioned: "3.5+ crore",
      houses_completed: "2+ crore",
      subsidy_beneficiaries: "30+ lakh",
    },
    eligibility:
      "EWS (annual income up to Rs. 3 lakh), LIG (Rs. 3-6 lakh), MIG-I (Rs. 6-12 lakh), MIG-II (Rs. 12-18 lakh). First-time home buyers only.",
    documents:
      "Aadhaar card, Income proof, Property documents, Bank statements, Passport size photographs.",
    status: "active" as const,
  },
  {
    title: "Swachh Bharat Mission (SBM)",
    content:
      "Nationwide cleanliness campaign launched on October 2, 2014. Two components: SBM-Gramin (rural) and SBM-Urban. Aims to eliminate open defecation, improve solid waste management, and ensure hygiene. Over 12 crore toilets built in rural areas. All 6 lakh villages in India declared ODF (Open Defecation Free). The mission has significantly reduced waterborne diseases and improved public health outcomes.",
    category: "social-welfare" as const,
    url: "https://swachhbharat.mygov.in",
    metrics: {
      toilets_built: "12+ crore",
      odf_villages: "6+ lakh",
      expenditure: "Rs. 1.5+ lakh crore",
    },
    eligibility:
      "All rural households without toilets are eligible for assistance. Priority given to SC/ST households, landless laborers, and small farmers.",
    documents:
      "Aadhaar card, Bank account details, Photograph of existing condition (if any).",
    status: "active" as const,
  },
  {
    title: "Smart Cities Mission",
    content:
      "Urban renewal program launched in June 2015 to develop 100 smart cities across India. Focuses on sustainable and inclusive development through area-based development and pan-city solutions. Key components include smart mobility, smart energy, smart water management, smart governance, and affordable housing. Total investment of Rs. 2.05 lakh crore approved. 7,800+ projects tendered, with 5,700+ work orders issued.",
    category: "infrastructure" as const,
    url: "https://smartcities.gov.in",
    metrics: {
      cities: "100",
      projects_tendered: "7,800+",
      investment: "Rs. 2.05 lakh crore",
    },
    eligibility:
      "Citizens of selected smart cities benefit directly. Specific projects may have individual eligibility criteria.",
    documents:
      "Varies by project. Generally requires proof of residence and identity.",
    status: "active" as const,
  },
  {
    title: "Atal Pension Yojana (APY)",
    content:
      "Pension scheme launched in May 2015 targeted at unorganized sector workers. Guaranteed minimum monthly pension of Rs. 1,000 to Rs. 5,000 from age 60. Government co-contributes 50% of subscriber's contribution or Rs. 1,000 per year (whichever is lower) for 5 years. Open to all Indian citizens aged 18-40 years. Over 5 crore subscribers enrolled. Focuses on providing social security to workers in informal sectors.",
    category: "financial-inclusion" as const,
    url: "https://npscra.nsdl.co.in",
    metrics: {
      subscribers: "5+ crore",
      pension_range: "Rs. 1,000-5,000/month",
      age_range: "18-40 years",
    },
    eligibility:
      "Indian citizen aged 18-40 years. Must have a savings bank account and valid mobile number. Not an income tax payer.",
    documents:
      "Aadhaar card, Bank account details, Mobile number. Enrollment form at bank or online.",
    status: "active" as const,
  },
  {
    title: "Pradhan Mantri Ujjwala Yojana (PMUY)",
    content:
      "Scheme launched in May 2016 to provide LPG connections to women from below-poverty-line (BPL) households. Initially targeted 5 crore women, expanded to 8 crore in PMUY 2.0 (2021). Provides free LPG connection with first refill and stove subsidy. Reduces health hazards from traditional cooking fuels (wood, coal, dung). Over 10 crore connections released. Significant improvement in women's health and time savings.",
    category: "social-welfare" as const,
    url: "https://pmuy.gov.in",
    metrics: {
      connections: "10+ crore",
      beneficiaries: "10+ crore women",
      lpg_coverage: "99.8%",
    },
    eligibility:
      "Adult woman from BPL household as per SECC-2011 data. No existing LPG connection in the household.",
    documents:
      "Aadhaar card, BPL ration card, Bank account details. Can apply through nearest LPG distributor.",
    status: "active" as const,
  },
  {
    title: "Digital India Programme",
    content:
      "Flagship program launched in July 2015 to transform India into a digitally empowered society. Three vision areas: digital infrastructure, digital services, and digital literacy. Key initiatives include BharatNet (broadband to 2.5 lakh Gram Panchayats), Common Service Centres (CSCs), DigiLocker, UMANG app, and e-Hospital. Over 50 crore internet users, 1.5 lakh+ CSCs operational. Significant push towards paperless governance.",
    category: "infrastructure" as const,
    url: "https://digitalindia.gov.in",
    metrics: {
      internet_users: "50+ crore",
      csc_centers: "1.5+ lakh",
      digilocker_users: "15+ crore",
    },
    eligibility:
      "All Indian citizens. Specific services may require Aadhaar-linked authentication.",
    documents:
      "Aadhaar card for most services. Varies by specific Digital India service.",
    status: "active" as const,
  },
  {
    title: "Pradhan Mantri Kaushal Vikas Yojana (PMKVY)",
    content:
      "Skill development scheme launched in 2015 as part of Skill India Mission. Provides short-term training (200-600 hours) to youth in industry-relevant skills. Training cost fully borne by government. Includes Recognition of Prior Learning (RPL) for informal sector workers. Over 1.5 crore people trained. Covers 375+ job roles across 30+ sectors including construction, retail, hospitality, and IT.",
    category: "employment" as const,
    url: "https://pmkvyofficial.org",
    metrics: {
      people_trained: "1.5+ crore",
      job_roles: "375+",
      training_centers: "7,000+",
    },
    eligibility:
      "Indian youth aged 15-45 years. Prior educational qualification varies by job role. Unemployed or school/college dropouts given priority.",
    documents:
      "Aadhaar card, Age proof, Educational certificates (if any), Bank account details.",
    status: "active" as const,
  },
  {
    title: "Beti Bachao Beti Padhao (BBBP)",
    content:
      "Scheme launched in January 2015 to address declining child sex ratio and promote girl child education. Three pillars: prevention of gender-biased sex selection, ensuring survival and protection of the girl child, and ensuring education and participation of the girl child. Operates in 640 districts across India. Significant improvement in sex ratio at birth in targeted districts. Includes cash incentives through Sukanya Samriddhi Yojana.",
    category: "social-welfare" as const,
    url: "https://wcd.nic.in/bbbp-scheme",
    metrics: {
      districts_covered: "640",
      sex_ratio_improved: "20+ states",
      ssy_accounts: "3+ crore",
    },
    eligibility:
      "All girl children. Sukanya Samriddhi Yojana accounts can be opened for girls below 10 years.",
    documents:
      "Birth certificate of girl child, Aadhaar card of parents, Bank account details for SSY.",
    status: "active" as const,
  },
  {
    title: "National Pension System (NPS)",
    content:
      "Voluntary, defined contribution retirement savings scheme launched in 2004 (extended to all citizens in 2009). Market-linked returns with professional fund management. Two tiers: Tier I (mandatory, with withdrawal restrictions) and Tier II (voluntary, flexible withdrawals). Tax benefits under Section 80C and 80CCD(1B). Over 60 lakh central and state government employees enrolled, plus crores of voluntary subscribers.",
    category: "financial-inclusion" as const,
    url: "https://npscra.nsdl.co.in",
    metrics: {
      subscribers: "60+ lakh (govt)",
      aum: "Rs. 10+ lakh crore",
      fund_managers: "10",
    },
    eligibility:
      "Indian citizen aged 18-70 years. Both salaried and self-employed individuals can join.",
    documents:
      "Aadhaar card, PAN card, Bank account details, Cancelled cheque, Photograph. Can open online or through Points of Presence (POPs).",
    status: "active" as const,
  },
  {
    title: "Pradhan Mantri Vaya Vandana Yojana (PMVVY)",
    content:
      "Pension scheme for senior citizens aged 60 years and above. Provides assured pension ranging from Rs. 1,000 to Rs. 10,000 per month depending on investment amount. Maximum investment limit of Rs. 15 lakh. Policy term of 10 years. Pension can be paid monthly, quarterly, half-yearly, or annually. Administered by LIC of India. Guaranteed returns of 7.4% per annum.",
    category: "social-welfare" as const,
    url: "https://licindia.in",
    metrics: {
      pension_range: "Rs. 1,000-10,000/month",
      max_investment: "Rs. 15 lakh",
      return_rate: "7.4% p.a.",
    },
    eligibility:
      "Indian citizen aged 60 years and above. No medical examination required.",
    documents:
      "Aadhaar card, Age proof, Bank account details, Passport size photographs. Apply through LIC office or online.",
    status: "active" as const,
  },
  {
    title: "Pradhan Mantri Mudra Yojana (PMMY)",
    content:
      "Scheme launched in April 2015 to provide loans up to Rs. 10 lakh to non-corporate, non-farm small/micro enterprises. Three categories: Shishu (up to Rs. 50,000), Kishore (Rs. 50,000 to 5 lakh), and Tarun (Rs. 5 lakh to 10 lakh). No collateral required. Over 46 crore loans disbursed totaling Rs. 28+ lakh crore. Special focus on women entrepreneurs (68% beneficiaries are women).",
    category: "financial-inclusion" as const,
    url: "https://mudra.org.in",
    metrics: {
      loans_disbursed: "46+ crore",
      amount: "Rs. 28+ lakh crore",
      women_beneficiaries: "68%",
    },
    eligibility:
      "Any Indian citizen with a business plan for non-farm income generating activity. Includes small manufacturing units, shopkeepers, artisans, traders.",
    documents:
      "Identity proof (Aadhaar/PAN), Business plan/estimate, Bank account details. Apply at any commercial bank, RRB, MFI, or NBFC.",
    status: "active" as const,
  },
  {
    title: "National Health Mission (NHM)",
    content:
      "Comprehensive health program launched in 2013 (merging NRHM and NUHM). Aims to provide accessible, affordable, and quality healthcare to rural and urban populations. Components include Reproductive, Maternal, Newborn, Child and Adolescent Health (RMNCH+A), communicable and non-communicable disease control, and health system strengthening. Over 1.7 lakh health facilities functional. Significant reduction in maternal and infant mortality rates.",
    category: "healthcare" as const,
    url: "https://nhm.gov.in",
    metrics: {
      health_facilities: "1.7+ lakh",
      asha_workers: "10+ lakh",
      immunization_coverage: "90%+",
    },
    eligibility:
      "All Indian citizens, especially women and children in rural and urban underserved areas. BPL families given priority.",
    documents:
      "No specific documents required for most services. Ration card or Aadhaar may be needed for certain benefits.",
    status: "active" as const,
  },
];

async function seed() {
  const db = getDb();

  console.log("Seeding government schemes...");

  // Clear existing schemes
  await db.delete(schemes);

  // Insert all schemes
  for (const scheme of governmentSchemes) {
    await db.insert(schemes).values(scheme);
  }

  console.log(`Seeded ${governmentSchemes.length} government schemes.`);
}

seed().catch(console.error);

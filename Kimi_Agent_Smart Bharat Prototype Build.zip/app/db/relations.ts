import { relations } from "drizzle-orm";
import {
  users,
  profiles,
  schemes,
  complaints,
  complaintUpdates,
  chatSessions,
  chatMessages,
  savedSchemes,
} from "./schema";

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
  complaints: many(complaints),
  chatSessions: many(chatSessions),
  savedSchemes: many(savedSchemes),
}));

export const profilesRelations = relations(profiles, ({ one }) => ({
  user: one(users, {
    fields: [profiles.userId],
    references: [users.id],
  }),
}));

export const complaintsRelations = relations(complaints, ({ one, many }) => ({
  user: one(users, {
    fields: [complaints.userId],
    references: [users.id],
  }),
  updates: many(complaintUpdates),
}));

export const complaintUpdatesRelations = relations(complaintUpdates, ({ one }) => ({
  complaint: one(complaints, {
    fields: [complaintUpdates.complaintId],
    references: [complaints.id],
  }),
}));

export const chatSessionsRelations = relations(chatSessions, ({ one, many }) => ({
  user: one(users, {
    fields: [chatSessions.userId],
    references: [users.id],
  }),
  messages: many(chatMessages),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  session: one(chatSessions, {
    fields: [chatMessages.sessionId],
    references: [chatSessions.id],
  }),
}));

export const savedSchemesRelations = relations(savedSchemes, ({ one }) => ({
  user: one(users, {
    fields: [savedSchemes.userId],
    references: [users.id],
  }),
  scheme: one(schemes, {
    fields: [savedSchemes.schemeId],
    references: [schemes.id],
  }),
}));

import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  json,
} from "drizzle-orm/mysql-core";

// Users table (managed by auth system)
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Profiles table - extended user information
export const profiles = mysqlTable("profiles", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .unique(),
  phone: varchar("phone", { length: 20 }),
  location: varchar("location", { length: 255 }),
  preferredLanguage: mysqlEnum("preferredLanguage", ["en", "hi"]).default("en"),
  age: int("age"),
  occupation: mysqlEnum("occupation", [
    "student",
    "farmer",
    "professional",
    "business",
    "unemployed",
    "retired",
    "other",
  ]),
  incomeBracket: mysqlEnum("incomeBracket", [
    "below-1l",
    "1l-3l",
    "3l-5l",
    "5l-10l",
    "above-10l",
  ]),
  category: mysqlEnum("category", [
    "general",
    "sc",
    "st",
    "obc",
    "ews",
  ]).default("general"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = typeof profiles.$inferInsert;

// Government schemes table
export const schemes = mysqlTable("schemes", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content").notNull(),
  category: mysqlEnum("category", [
    "healthcare",
    "agriculture",
    "financial-inclusion",
    "infrastructure",
    "education",
    "housing",
    "social-welfare",
    "employment",
    "other",
  ]).notNull(),
  url: varchar("url", { length: 500 }),
  metrics: json("metrics"),
  eligibility: text("eligibility"),
  documents: text("documents"),
  status: mysqlEnum("status", ["active", "upcoming", "expired"]).default(
    "active"
  ),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Scheme = typeof schemes.$inferSelect;
export type InsertScheme = typeof schemes.$inferInsert;

// Complaints table
export const complaints = mysqlTable("complaints", {
  id: serial("id").primaryKey(),
  complaintId: varchar("complaintId", { length: 20 }).notNull().unique(),
  userId: bigint("userId", { mode: "number", unsigned: true }),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  category: mysqlEnum("category", [
    "water",
    "electricity",
    "roads",
    "sanitation",
    "public-transport",
    "education",
    "healthcare",
    "other",
  ]).notNull(),
  location: varchar("location", { length: 255 }).notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description").notNull(),
  status: mysqlEnum("status", [
    "pending",
    "under-review",
    "assigned",
    "in-progress",
    "resolved",
    "rejected",
  ]).default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Complaint = typeof complaints.$inferSelect;
export type InsertComplaint = typeof complaints.$inferInsert;

// Complaint updates table - timeline of status changes
export const complaintUpdates = mysqlTable("complaint_updates", {
  id: serial("id").primaryKey(),
  complaintId: bigint("complaintId", { mode: "number", unsigned: true })
    .notNull(),
  status: mysqlEnum("status", [
    "pending",
    "under-review",
    "assigned",
    "in-progress",
    "resolved",
    "rejected",
  ]).notNull(),
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ComplaintUpdate = typeof complaintUpdates.$inferSelect;
export type InsertComplaintUpdate = typeof complaintUpdates.$inferInsert;

// Chat sessions table
export const chatSessions = mysqlTable("chat_sessions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }),
  title: varchar("title", { length: 255 }).default("New Chat"),
  language: mysqlEnum("language", ["en", "hi"]).default("en"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertChatSession = typeof chatSessions.$inferInsert;

// Chat messages table
export const chatMessages = mysqlTable("chat_messages", {
  id: serial("id").primaryKey(),
  sessionId: bigint("sessionId", { mode: "number", unsigned: true }).notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  sources: json("sources"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

// Saved schemes table
export const savedSchemes = mysqlTable("saved_schemes", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  schemeId: bigint("schemeId", { mode: "number", unsigned: true }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SavedScheme = typeof savedSchemes.$inferSelect;
export type InsertSavedScheme = typeof savedSchemes.$inferInsert;

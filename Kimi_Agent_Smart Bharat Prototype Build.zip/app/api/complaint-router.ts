import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { complaints, complaintUpdates } from "@db/schema";
import { eq, desc } from "drizzle-orm";

function generateComplaintId(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let result = "SB-";
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export const complaintRouter = createRouter({
  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(255),
        phone: z.string().min(10).max(20),
        category: z.enum([
          "water",
          "electricity",
          "roads",
          "sanitation",
          "public-transport",
          "education",
          "healthcare",
          "other",
        ]),
        location: z.string().min(1).max(255),
        title: z.string().min(1).max(500),
        description: z.string().min(1),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();

      // Generate unique complaint ID
      let complaintId = generateComplaintId();
      let exists = await db
        .select()
        .from(complaints)
        .where(eq(complaints.complaintId, complaintId))
        .limit(1);

      // Ensure uniqueness
      while (exists.length > 0) {
        complaintId = generateComplaintId();
        exists = await db
          .select()
          .from(complaints)
          .where(eq(complaints.complaintId, complaintId))
          .limit(1);
      }

      const userId = ctx.user?.id;

      const result = await db.insert(complaints).values({
        complaintId,
        userId: userId ?? null,
        name: input.name,
        phone: input.phone,
        category: input.category,
        location: input.location,
        title: input.title,
        description: input.description,
        status: "pending",
      });

      // Add initial status update
      await db.insert(complaintUpdates).values({
        complaintId: Number(result[0].insertId),
        status: "pending",
        note: "Complaint submitted successfully. Under review.",
      });

      return { complaintId, id: Number(result[0].insertId) };
    }),

  track: publicQuery
    .input(
      z
        .object({
          complaintId: z.string().optional(),
          phone: z.string().optional(),
        })
        .refine(
          (data) => data.complaintId || data.phone,
          "Either complaintId or phone is required"
        )
    )
    .query(async ({ input }) => {
      const db = getDb();

      if (input.complaintId) {
        const results = await db
          .select()
          .from(complaints)
          .where(eq(complaints.complaintId, input.complaintId))
          .orderBy(desc(complaints.createdAt));
        return results;
      }
      if (input.phone) {
        const results = await db
          .select()
          .from(complaints)
          .where(eq(complaints.phone, input.phone))
          .orderBy(desc(complaints.createdAt));
        return results;
      }
      return [];
    }),

  getTimeline: publicQuery
    .input(z.object({ complaintId: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();

      // First get the complaint
      const complaintResult = await db
        .select()
        .from(complaints)
        .where(eq(complaints.complaintId, input.complaintId))
        .limit(1);

      if (complaintResult.length === 0) {
        return null;
      }

      const complaint = complaintResult[0];

      // Get updates timeline
      const updates = await db
        .select()
        .from(complaintUpdates)
        .where(eq(complaintUpdates.complaintId, complaint.id))
        .orderBy(complaintUpdates.createdAt);

      return {
        complaint,
        timeline: updates,
      };
    }),
});

import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { chatSessions, chatMessages } from "@db/schema";
import { eq, desc } from "drizzle-orm";
import { sendMessage } from "./ai-service";

export const chatRouter = createRouter({
  createSession: publicQuery
    .input(
      z
        .object({
          title: z.string().optional(),
          language: z.enum(["en", "hi"]).optional(),
        })
        .optional()
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user ? ctx.user.id : null;

      const result = await db.insert(chatSessions).values({
        userId,
        title: input?.title ?? "New Chat",
        language: input?.language ?? "en",
      });

      const session = await db
        .select()
        .from(chatSessions)
        .where(eq(chatSessions.id, Number(result[0].insertId)))
        .limit(1);

      return session[0];
    }),

  getSessions: publicQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user?.id;

    if (!userId) {
      return [];
    }

    const sessions = await db
      .select()
      .from(chatSessions)
      .where(eq(chatSessions.userId, userId))
      .orderBy(desc(chatSessions.createdAt))
      .limit(50);

    return sessions;
  }),

  getMessages: publicQuery
    .input(z.object({ sessionId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();

      const messages = await db
        .select()
        .from(chatMessages)
        .where(eq(chatMessages.sessionId, input.sessionId))
        .orderBy(chatMessages.createdAt);

      return messages;
    }),

  sendMessage: publicQuery
    .input(
      z.object({
        sessionId: z.number(),
        message: z.string().min(1).max(2000),
        language: z.enum(["en", "hi"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Get session info
      const session = await db
        .select()
        .from(chatSessions)
        .where(eq(chatSessions.id, input.sessionId))
        .limit(1);

      if (session.length === 0) {
        throw new Error("Chat session not found");
      }

      const chatSession = session[0];
      const language = input.language ?? chatSession.language ?? "en";

      // Save user message
      await db.insert(chatMessages).values({
        sessionId: input.sessionId,
        role: "user",
        content: input.message,
      });

      // Get chat history for context
      const history = await db
        .select()
        .from(chatMessages)
        .where(eq(chatMessages.sessionId, input.sessionId))
        .orderBy(chatMessages.createdAt)
        .limit(10);

      const chatHistory = history.map((h) => ({
        role: h.role,
        content: h.content,
      }));

      // Get AI response
      const aiResponse = await sendMessage(
        input.message,
        language,
        chatHistory
      );

      // Save AI response
      await db.insert(chatMessages).values({
        sessionId: input.sessionId,
        role: "assistant",
        content: aiResponse.reply,
        sources: aiResponse.sources ?? [],
      });

      // Update session title if it's the first message
      if (chatSession.title === "New Chat" && history.length <= 1) {
        const shortTitle =
          input.message.length > 40
            ? input.message.substring(0, 40) + "..."
            : input.message;
        await db
          .update(chatSessions)
          .set({ title: shortTitle })
          .where(eq(chatSessions.id, input.sessionId));
      }

      return aiResponse;
    }),
});

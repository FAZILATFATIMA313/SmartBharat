import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { profiles, schemes, savedSchemes } from "@db/schema";
import { eq, and, inArray } from "drizzle-orm";

export const profileRouter = createRouter({
  get: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;

    const result = await db
      .select()
      .from(profiles)
      .where(eq(profiles.userId, userId))
      .limit(1);

    return result[0] ?? null;
  }),

  upsert: authedQuery
    .input(
      z.object({
        phone: z.string().max(20).optional(),
        location: z.string().max(255).optional(),
        preferredLanguage: z.enum(["en", "hi"]).optional(),
        age: z.number().min(0).max(120).optional(),
        occupation: z
          .enum([
            "student",
            "farmer",
            "professional",
            "business",
            "unemployed",
            "retired",
            "other",
          ])
          .optional(),
        incomeBracket: z
          .enum(["below-1l", "1l-3l", "3l-5l", "5l-10l", "above-10l"])
          .optional(),
        category: z
          .enum(["general", "sc", "st", "obc", "ews"])
          .optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Check if profile exists
      const existing = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, userId))
        .limit(1);

      if (existing.length > 0) {
        // Update
        await db
          .update(profiles)
          .set({
            ...input,
            updatedAt: new Date(),
          })
          .where(eq(profiles.userId, userId));

        const updated = await db
          .select()
          .from(profiles)
          .where(eq(profiles.userId, userId))
          .limit(1);

        return updated[0];
      } else {
        // Create
        const result = await db.insert(profiles).values({
          userId,
          ...input,
        });

        const created = await db
          .select()
          .from(profiles)
          .where(eq(profiles.id, Number(result[0].insertId)))
          .limit(1);

        return created[0];
      }
    }),

  getRecommendations: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;

    // Get user profile
    const profile = await db
      .select()
      .from(profiles)
      .where(eq(profiles.userId, userId))
      .limit(1);

    if (profile.length === 0) {
      // Return top active schemes if no profile
      return await db
        .select()
        .from(schemes)
        .where(eq(schemes.status, "active"))
        .limit(6);
    }

    const p = profile[0];
    const recommendedCategories: string[] = [];

    // Map profile to scheme categories
    if (p.age && p.age >= 60) {
      recommendedCategories.push("social-welfare", "healthcare");
    }
    if (p.age && p.age <= 25) {
      recommendedCategories.push("education", "employment");
    }
    if (p.occupation === "farmer") {
      recommendedCategories.push("agriculture", "financial-inclusion");
    }
    if (p.occupation === "student") {
      recommendedCategories.push("education", "employment");
    }
    if (p.occupation === "unemployed") {
      recommendedCategories.push("employment", "financial-inclusion");
    }
    if (p.occupation === "retired") {
      recommendedCategories.push("social-welfare", "healthcare");
    }
    if (p.incomeBracket === "below-1l" || p.incomeBracket === "1l-3l") {
      recommendedCategories.push("social-welfare", "housing", "healthcare");
    }
    if (
      p.category === "sc" ||
      p.category === "st" ||
      p.category === "obc"
    ) {
      recommendedCategories.push("education", "housing", "employment");
    }

    // Always include these
    recommendedCategories.push("financial-inclusion", "healthcare");

    // Deduplicate
    const uniqueCategories = [...new Set(recommendedCategories)];

    // Get recommended schemes
    const recommended = await db
      .select()
      .from(schemes)
      .where(
        and(
          eq(schemes.status, "active"),
          inArray(schemes.category, uniqueCategories as any)
        )
      )
      .limit(8);

    return recommended;
  }),
});

export const savedSchemeRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;

    const saved = await db
      .select({
        id: savedSchemes.id,
        schemeId: savedSchemes.schemeId,
        createdAt: savedSchemes.createdAt,
      })
      .from(savedSchemes)
      .where(eq(savedSchemes.userId, userId));

    if (saved.length === 0) return [];

    const schemeIds = saved.map((s) => s.schemeId);
    const schemeList = await db
      .select()
      .from(schemes)
      .where(inArray(schemes.id, schemeIds));

    return schemeList;
  }),

  save: authedQuery
    .input(z.object({ schemeId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Check if already saved
      const existing = await db
        .select()
        .from(savedSchemes)
        .where(
          and(
            eq(savedSchemes.userId, userId),
            eq(savedSchemes.schemeId, input.schemeId)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        return existing[0];
      }

      const result = await db.insert(savedSchemes).values({
        userId,
        schemeId: input.schemeId,
      });

      return { id: Number(result[0].insertId), schemeId: input.schemeId };
    }),

  remove: authedQuery
    .input(z.object({ schemeId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const db = getDb();
      const userId = ctx.user.id;

      await db
        .delete(savedSchemes)
        .where(
          and(
            eq(savedSchemes.userId, userId),
            eq(savedSchemes.schemeId, input.schemeId)
          )
        );

      return { success: true };
    }),
});

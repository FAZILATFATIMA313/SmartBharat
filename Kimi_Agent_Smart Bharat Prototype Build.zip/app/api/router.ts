import { authRouter } from "./auth-router";
import { schemeRouter } from "./scheme-router";
import { complaintRouter } from "./complaint-router";
import { chatRouter } from "./chat-router";
import { profileRouter, savedSchemeRouter } from "./profile-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  scheme: schemeRouter,
  complaint: complaintRouter,
  chat: chatRouter,
  profile: profileRouter,
  savedScheme: savedSchemeRouter,
});

export type AppRouter = typeof appRouter;

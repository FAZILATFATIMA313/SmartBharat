import Groq from "groq-sdk";
import { getDb } from "./queries/connection";
import { schemes } from "@db/schema";
import { sql } from "drizzle-orm";

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY || "",
});

export interface AIServiceResponse {
  reply: string;
  sources?: Array<{
    id: number;
    title: string;
    category: string;
    url: string | null;
  }>;
}

function buildSystemPrompt(schemeContext: string, language: string): string {
  const langInstruction =
    language === "hi"
      ? "Hindi mein jawab den. Uttar saaf aur saral bhasha mein hona chahiye."
      : "Respond in clear, simple English.";

  return `You are Smart Bharat, an AI-powered civic companion for Indian citizens. Your role is to help users discover government schemes, understand eligibility criteria, and guide them through application processes.

You have access to the following government schemes:
${schemeContext}

Guidelines:
- Provide accurate, concise information about government schemes
- Always cite the official source URL when available
- If unsure, admit uncertainty and suggest contacting official channels
- ${langInstruction}
- Format responses with clear sections using markdown
- Include eligibility criteria, required documents, and application steps when relevant
- Be empathetic and helpful, especially for rural or underprivileged users
- If the user asks in a language other than the response language, translate and respond
- Keep responses under 400 words unless detailed information is specifically requested`;
}

export async function sendMessage(
  message: string,
  language: string = "en",
  chatHistory: Array<{ role: string; content: string }> = []
): Promise<AIServiceResponse> {
  try {
    const db = getDb();

    // Search for relevant schemes
    const searchTerm = `%${message}%`;
    const relevantSchemes = await db
      .select()
      .from(schemes)
      .where(
        sql`${schemes.title} LIKE ${searchTerm} OR ${schemes.content} LIKE ${searchTerm} OR ${schemes.category} LIKE ${searchTerm}`
      )
      .limit(5);

    // If no direct match, try broader search
    let searchResults = relevantSchemes;
    if (relevantSchemes.length === 0) {
      // Extract keywords from message
      const keywords = message
        .toLowerCase()
        .split(/\s+/)
        .filter(
          (w) =>
            w.length > 3 &&
            !["what", "when", "where", "which", "about", "tell", "how", "the", "and", "for", "this", "that", "with"].includes(w)
        )
        .slice(0, 3);

      if (keywords.length > 0) {
        const conditions = keywords.map(
          (kw) => sql`${schemes.title} LIKE ${`%${kw}%`} OR ${schemes.content} LIKE ${`%${kw}%`}`
        );
        searchResults = await db
          .select()
          .from(schemes)
          .where(sql`(${sql.join(conditions, sql` OR `)})`)
          .limit(5);
      }
    }

    // Build context from search results
    let schemeContext = "";
    if (searchResults.length > 0) {
      schemeContext = searchResults
        .map(
          (s, i) =>
            `${i + 1}. ${s.title} (${s.category})\n${s.content.substring(0, 400)}${s.url ? `\nOfficial: ${s.url}` : ""}`
        )
        .join("\n\n");
    } else {
      schemeContext = "No specific schemes found in the database for this query. Provide general guidance about how to find and apply for government schemes in India.";
    }

    // Build messages for Groq
    const systemPrompt = buildSystemPrompt(schemeContext, language);

    const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
      { role: "system", content: systemPrompt },
      ...chatHistory.map((h) => ({
        role: h.role as "user" | "assistant",
        content: h.content,
      })),
      { role: "user", content: message },
    ];

    const completion = await groq.chat.completions.create({
      messages,
      model: "llama-3.3-70b-versatile",
      temperature: 0.7,
      max_tokens: 1024,
      top_p: 1,
    });

    const reply = completion.choices[0]?.message?.content || "I apologize, but I couldn't generate a response. Please try again.";

    return {
      reply,
      sources: searchResults.map((s) => ({
        id: s.id,
        title: s.title,
        category: s.category,
        url: s.url,
      })),
    };
  } catch (error) {
    console.error("AI Service Error:", error);

    // Fallback response if AI fails
    return {
      reply:
        language === "hi"
          ? "Maaf kijiye, mujhe is samay jawab dene mein samasya ho rahi hai. Kripya baad mein prayas karein ya yojna ki adhik jankari ke liye myscheme.gov.in par visit karein."
          : "I apologize, but I'm experiencing technical difficulties. Please try again later or visit myscheme.gov.in for more information about government schemes.",
      sources: [],
    };
  }
}

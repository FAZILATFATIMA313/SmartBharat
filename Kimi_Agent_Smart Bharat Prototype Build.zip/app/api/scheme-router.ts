import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { schemes } from "@db/schema";
import { eq, and, sql, desc } from "drizzle-orm";

export const schemeRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          category: z.string().optional(),
          status: z.string().optional(),
          search: z.string().optional(),
          page: z.number().min(1).default(1),
          limit: z.number().min(1).max(50).default(12),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const {
        category,
        status,
        search,
        page = 1,
        limit = 12,
      } = input ?? {};

      const conditions = [];

      if (category && category !== "all") {
        conditions.push(eq(schemes.category, category as any));
      }

      if (status && status !== "all") {
        conditions.push(eq(schemes.status, status as any));
      }

      if (search) {
        conditions.push(
          sql`${schemes.title} LIKE ${`%${search}%`} OR ${schemes.content} LIKE ${`%${search}%`}`
        );
      }

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const totalResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(schemes)
        .where(whereClause);

      const total = Number(totalResult[0]?.count ?? 0);

      const results = await db
        .select()
        .from(schemes)
        .where(whereClause)
        .limit(limit)
        .offset((page - 1) * limit)
        .orderBy(desc(schemes.createdAt));

      return {
        schemes: results,
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      };
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select()
        .from(schemes)
        .where(eq(schemes.id, input.id))
        .limit(1);

      return result[0] ?? null;
    }),

  categories: publicQuery.query(async () => {
    const db = getDb();
    const results = await db
      .selectDistinct({ category: schemes.category })
      .from(schemes);

    return results.map((r) => r.category);
  }),

  search: publicQuery
    .input(z.object({ query: z.string().min(1) }))
    .query(async ({ input }) => {
      const db = getDb();
      const searchTerm = `%${input.query}%`;

      const results = await db
        .select()
        .from(schemes)
        .where(
          sql`${schemes.title} LIKE ${searchTerm} OR ${schemes.content} LIKE ${searchTerm} OR ${schemes.category} LIKE ${searchTerm}`
        )
        .limit(5);

      return results;
    }),
});

import { useState, useCallback } from "react";
import { getTranslation, type Language } from "@/lib/i18n";

const LANGUAGE_KEY = "smart-bharat-language";

function getStoredLanguage(): Language {
  if (typeof window === "undefined") return "en";
  const stored = localStorage.getItem(LANGUAGE_KEY) as Language | null;
  return stored === "hi" ? "hi" : "en";
}

export function useLanguage() {
  const [language, setLanguageState] = useState<Language>(getStoredLanguage);

  const setLanguage = useCallback((lang: Language | ((prev: Language) => Language)) => {
    setLanguageState((prev) => {
      const newLang = typeof lang === "function" ? lang(prev) : lang;
      localStorage.setItem(LANGUAGE_KEY, newLang);
      return newLang;
    });
  }, []);

  const t = getTranslation(language);

  return { language, setLanguage, t };
}

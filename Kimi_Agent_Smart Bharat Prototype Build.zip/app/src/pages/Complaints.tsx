import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useLanguage } from "@/hooks/useLanguage";
import {
  FileText,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  Send,
  MapPin,
  Phone,
  User,
  Tag,
  AlignLeft,
  ClipboardList,
  X,
} from "lucide-react";

const statusColors: Record<string, { bg: string; text: string; icon: typeof Clock }> = {
  pending: { bg: "bg-yellow-500/10", text: "text-yellow-400", icon: Clock },
  "under-review": { bg: "bg-blue-500/10", text: "text-blue-400", icon: AlertCircle },
  assigned: { bg: "bg-purple-500/10", text: "text-purple-400", icon: ClipboardList },
  "in-progress": { bg: "bg-orange-500/10", text: "text-orange-400", icon: Clock },
  resolved: { bg: "bg-green-500/10", text: "text-green-400", icon: CheckCircle2 },
  rejected: { bg: "bg-red-500/10", text: "text-red-400", icon: X },
};

export default function Complaints() {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<"file" | "track">("file");
  const [searchValue, setSearchValue] = useState("");
  const [searchType, setSearchType] = useState<"id" | "phone">("id");
  const [filedComplaint, setFiledComplaint] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    category: "other" as "water" | "electricity" | "roads" | "sanitation" | "public-transport" | "education" | "healthcare" | "other",
    location: "",
    title: "",
    description: "",
  });

  const createComplaint = trpc.complaint.create.useMutation();
  const [doSearch, setDoSearch] = useState(false);
  const searchResults = trpc.complaint.track.useQuery(
    searchType === "id"
      ? { complaintId: searchValue }
      : { phone: searchValue },
    { enabled: doSearch && searchValue.length > 0 }
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const result = await createComplaint.mutateAsync(formData);
      setFiledComplaint(result.complaintId);
      setFormData({
        name: "",
        phone: "",
        category: "other",
        location: "",
        title: "",
        description: "",
      });
    } catch (error) {
      console.error("Failed to file complaint:", error);
    }
  };

  const handleTrack = () => {
    if (searchValue.trim()) {
      setDoSearch(true);
    }
  };

  const complaintCategories = [
    { value: "water" as const, label: t.complaints.categories.water },
    { value: "electricity" as const, label: t.complaints.categories.electricity },
    { value: "roads" as const, label: t.complaints.categories.roads },
    { value: "sanitation" as const, label: t.complaints.categories.sanitation },
    { value: "public-transport" as const, label: t.complaints.categories.publicTransport },
    { value: "education" as const, label: t.complaints.categories.education },
    { value: "healthcare" as const, label: t.complaints.categories.healthcare },
    { value: "other" as const, label: t.complaints.categories.other },
  ];

  return (
    <div className="pt-20 pb-16 px-4 min-h-screen">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-[#F8FAFC] mb-2">
            {t.complaints.title}
          </h1>
          <p className="text-[#94A3B8]">
            File grievances and track their status in real-time
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-[#111D2E] rounded-xl mb-8 border border-[#1A2A3F]">
          <button
            onClick={() => {
              setActiveTab("file");
              setFiledComplaint(null);
            }}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-medium transition-all ${
              activeTab === "file"
                ? "bg-[#FF9933] text-[#0A1628]"
                : "text-[#94A3B8] hover:text-[#F8FAFC]"
            }`}
          >
            <FileText size={16} />
            {t.complaints.fileComplaint}
          </button>
          <button
            onClick={() => {
              setActiveTab("track");
              setFiledComplaint(null);
              setDoSearch(false);
            }}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-medium transition-all ${
              activeTab === "track"
                ? "bg-[#FF9933] text-[#0A1628]"
                : "text-[#94A3B8] hover:text-[#F8FAFC]"
            }`}
          >
            <Search size={16} />
            {t.complaints.trackComplaint}
          </button>
        </div>

        {/* File Complaint Tab */}
        {activeTab === "file" && (
          <div>
            {filedComplaint ? (
              <div className="card-dark text-center p-12">
                <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 size={32} className="text-green-400" />
                </div>
                <h2 className="text-2xl font-bold text-[#F8FAFC] mb-2">
                  {t.complaints.form.success}
                </h2>
                <p className="text-[#94A3B8] mb-2">{t.complaints.form.complaintId}</p>
                <p className="text-3xl font-mono font-bold text-[#FF9933] mb-6">
                  {filedComplaint}
                </p>
                <div className="flex gap-3 justify-center">
                  <button
                    onClick={() => {
                      setActiveTab("track");
                      setSearchValue(filedComplaint);
                      setSearchType("id");
                      setDoSearch(true);
                      setFiledComplaint(null);
                    }}
                    className="btn-saffron"
                  >
                    Track Complaint
                  </button>
                  <button
                    onClick={() => setFiledComplaint(null)}
                    className="btn-outline"
                  >
                    File Another
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="card-dark space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-[#E2E8F0] mb-2">
                      <User size={14} className="inline mr-1" />
                      {t.complaints.form.name}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      className="input-dark"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#E2E8F0] mb-2">
                      <Phone size={14} className="inline mr-1" />
                      {t.complaints.form.phone}
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({ ...formData, phone: e.target.value })
                      }
                      className="input-dark"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-[#E2E8F0] mb-2">
                      <Tag size={14} className="inline mr-1" />
                      {t.complaints.form.category}
                    </label>
                    <select
                      value={formData.category}
                      onChange={(e) =>
                        setFormData({ ...formData, category: e.target.value as typeof formData.category })
                      }
                      className="input-dark appearance-none cursor-pointer"
                    >
                      {complaintCategories.map((cat) => (
                        <option key={cat.value} value={cat.value}>
                          {cat.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#E2E8F0] mb-2">
                      <MapPin size={14} className="inline mr-1" />
                      {t.complaints.form.location}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.location}
                      onChange={(e) =>
                        setFormData({ ...formData, location: e.target.value })
                      }
                      className="input-dark"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#E2E8F0] mb-2">
                    <FileText size={14} className="inline mr-1" />
                    {t.complaints.form.title}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                    className="input-dark"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#E2E8F0] mb-2">
                    <AlignLeft size={14} className="inline mr-1" />
                    {t.complaints.form.description}
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={formData.description}
                    onChange={(e) =>
                      setFormData({ ...formData, description: e.target.value })
                    }
                    className="input-dark resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={createComplaint.isPending}
                  className="w-full btn-saffron flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Send size={18} />
                  {createComplaint.isPending ? "Submitting..." : t.complaints.form.submit}
                </button>
              </form>
            )}
          </div>
        )}

        {/* Track Complaint Tab */}
        {activeTab === "track" && (
          <div className="space-y-6">
            {/* Search */}
            <div className="card-dark">
              <label className="block text-sm font-medium text-[#E2E8F0] mb-3">
                {t.complaints.track.searchLabel}
              </label>
              <div className="flex gap-3">
                <div className="flex gap-1 bg-[#0A1628] rounded-lg p-1">
                  <button
                    onClick={() => setSearchType("id")}
                    className={`px-3 py-2 rounded-md text-xs font-medium transition-all ${
                      searchType === "id"
                        ? "bg-[#FF9933] text-[#0A1628]"
                        : "text-[#94A3B8] hover:text-[#F8FAFC]"
                    }`}
                  >
                    ID
                  </button>
                  <button
                    onClick={() => setSearchType("phone")}
                    className={`px-3 py-2 rounded-md text-xs font-medium transition-all ${
                      searchType === "phone"
                        ? "bg-[#FF9933] text-[#0A1628]"
                        : "text-[#94A3B8] hover:text-[#F8FAFC]"
                    }`}
                  >
                    Phone
                  </button>
                </div>
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={searchValue}
                    onChange={(e) => {
                      setSearchValue(e.target.value);
                      setDoSearch(false);
                    }}
                    onKeyDown={(e) => e.key === "Enter" && handleTrack()}
                    placeholder={t.complaints.track.searchPlaceholder}
                    className="input-dark w-full"
                  />
                </div>
                <button
                  onClick={handleTrack}
                  className="btn-saffron flex items-center gap-2"
                >
                  <Search size={16} />
                  {t.complaints.track.search}
                </button>
              </div>
            </div>

            {/* Results */}
            {searchResults.isLoading && (
              <div className="text-center py-8">
                <div className="animate-pulse text-[#94A3B8]">Searching...</div>
              </div>
            )}

            {searchResults.data && searchResults.data.length === 0 && doSearch && (
              <div className="card-dark text-center py-8">
                <p className="text-[#94A3B8]">{t.complaints.track.noResults}</p>
              </div>
            )}

            {searchResults.data && searchResults.data.length > 0 && (
              <div className="space-y-4">
                {searchResults.data.map((complaint) => {
                  const statusKey = complaint.status ?? "pending";
                  const statusConfig = statusColors[statusKey] ?? statusColors.pending;
                  const StatusIcon = statusConfig.icon;

                  return (
                    <div
                      key={complaint.id}
                      className="card-dark border-l-4"
                      style={{ borderLeftColor: "#FF9933" }}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-mono text-sm text-[#FF9933]">
                            {complaint.complaintId}
                          </p>
                          <h3 className="text-lg font-semibold text-[#F8FAFC] mt-1">
                            {complaint.title}
                          </h3>
                        </div>
                        <span
                          className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${statusConfig.bg} ${statusConfig.text}`}
                        >
                          <StatusIcon size={12} />
                          {statusKey.replace("-", " ")}
                        </span>
                      </div>

                      <div className="flex flex-wrap gap-4 text-sm text-[#94A3B8] mb-3">
                        <span className="capitalize">
                          {complaint.category.replace("-", " ")}
                        </span>
                        <span>{complaint.location}</span>
                        <span>{new Date(complaint.createdAt).toLocaleDateString()}</span>
                      </div>

                      <p className="text-sm text-[#E2E8F0]">{complaint.description}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

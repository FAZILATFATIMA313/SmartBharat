import { useEffect, useRef } from "react";
import { Link } from "react-router";
import { AshokaChakra } from "@/components/AshokaChakra";
import { useLanguage } from "@/hooks/useLanguage";
import {
  MessageSquare,
  ClipboardList,
  Languages,
  Search,
  Cpu,
  FileCheck,
  ArrowRight,
  Sparkles,
} from "lucide-react";

// Particle Network Background
function ParticleNetwork() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
    }> = [];

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    const init = () => {
      resize();
      const count = 60;
      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * canvas.offsetWidth,
          y: Math.random() * canvas.offsetHeight,
          vx: (Math.random() - 0.5) * 0.6,
          vy: (Math.random() - 0.5) * 0.6,
        });
      }
    };

    const animate = () => {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      ctx.clearRect(0, 0, w, h);

      // Update and draw particles
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255,153,51,0.4)";
        ctx.fill();
      }

      // Draw connections
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(255,153,51,${0.15 * (1 - dist / 120)})`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      }

      animationId = requestAnimationFrame(animate);
    };

    init();
    animate();
    window.addEventListener("resize", resize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ zIndex: 0 }}
    />
  );
}

// CountUp animation hook
function useCountUp(end: number, duration: number = 2000) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started) {
          setStarted(true);
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;

    let startTime: number;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * end));
      if (progress < 1) requestAnimationFrame(step);
    };

    requestAnimationFrame(step);
  }, [started, end, duration]);

  return { count, ref };
}

import { useState } from "react";

function StatCard({ value, suffix, label }: { value: number; suffix: string; label: string }) {
  const { count, ref } = useCountUp(value);
  return (
    <div ref={ref} className="card-dark text-center p-6">
      <div className="text-3xl md:text-4xl font-bold text-[#FF9933]">
        {count.toLocaleString("en-IN")}
        {suffix}
      </div>
      <div className="mt-2 text-sm text-[#94A3B8]">{label}</div>
    </div>
  );
}

// Scroll reveal hook
function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true);
      },
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return { ref, visible };

}

export default function Home() {
  const { t } = useLanguage();

  const features = [
    {
      icon: MessageSquare,
      title: t.features.aiAssistant.title,
      description: t.features.aiAssistant.description,
    },
    {
      icon: ClipboardList,
      title: t.features.complaintTracking.title,
      description: t.features.complaintTracking.description,
    },
    {
      icon: Languages,
      title: t.features.multilingual.title,
      description: t.features.multilingual.description,
    },
  ];

  const howItWorksSteps = [
    { icon: Search, ...t.howItWorks.steps[0] },
    { icon: Cpu, ...t.howItWorks.steps[1] },
    { icon: FileCheck, ...t.howItWorks.steps[2] },
    { icon: Sparkles, ...t.howItWorks.steps[3] },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
        <ParticleNetwork />
        <div className="absolute top-8 right-8 opacity-10 animate-spin-slow pointer-events-none hidden lg:block">
          <AshokaChakra size={120} animate />
        </div>

        <div className="relative z-10 text-center max-w-3xl mx-auto px-4">
          <div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-6 animate-fade-in"
            style={{
              background: "rgba(255,153,51,0.1)",
              border: "1px solid rgba(255,153,51,0.2)",
              color: "#FF9933",
            }}
          >
            <Sparkles size={16} />
            {t.hero.badge}
          </div>

          <h1
            className="text-4xl md:text-6xl font-extrabold text-[#F8FAFC] mb-6 animate-slide-up"
            style={{ animationDelay: "0.2s", animationFillMode: "both" }}
          >
            {t.hero.headline}
          </h1>

          <p
            className="text-lg md:text-xl text-[#94A3B8] mb-8 max-w-2xl mx-auto animate-slide-up"
            style={{ animationDelay: "0.4s", animationFillMode: "both" }}
          >
            {t.hero.subheadline}
          </p>

          <div
            className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up"
            style={{ animationDelay: "0.6s", animationFillMode: "both" }}
          >
            <Link to="/chat" className="btn-saffron inline-flex items-center justify-center gap-2">
              <MessageSquare size={20} />
              {t.hero.ctaChat}
            </Link>
            <Link to="/schemes" className="btn-outline inline-flex items-center justify-center gap-2">
              {t.hero.ctaSchemes}
              <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatCard value={50} suffix="+" label={t.stats.schemes} />
          <StatCard value={2} suffix="+" label={t.stats.languages} />
          <StatCard value={24} suffix="/7" label={t.stats.support} />
          <StatCard value={100000} suffix="+" label={t.stats.citizens} />
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#F8FAFC] mb-12">
            {t.features.title}
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature, i) => {
              const { ref, visible } = useScrollReveal();
              return (
                <div
                  key={i}
                  ref={ref}
                  className={`card-dark p-8 transition-all duration-600 ${
                    visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                  }`}
                  style={{ transitionDelay: `${i * 100}ms` }}
                >
                  <div className="w-12 h-12 rounded-lg bg-[#FF9933]/10 flex items-center justify-center mb-4">
                    <feature.icon size={24} className="text-[#FF9933]" />
                  </div>
                  <h3 className="text-xl font-semibold text-[#F8FAFC] mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-[#94A3B8] leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#F8FAFC] mb-12">
            {t.howItWorks.title}
          </h2>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-px bg-[#1A2A3F] md:-translate-x-px" />

            {howItWorksSteps.map((step, i) => {
              const { ref, visible } = useScrollReveal();
              return (
                <div
                  key={i}
                  ref={ref}
                  className={`relative flex items-start gap-6 mb-12 last:mb-0 transition-all duration-600 ${
                    visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                  }`}
                  style={{ transitionDelay: `${i * 150}ms` }}
                >
                  <div
                    className={`flex-shrink-0 w-12 h-12 rounded-full bg-[#FF9933] flex items-center justify-center z-10 ${
                      i % 2 === 0 ? "md:order-1" : "md:order-2"
                    }`}
                  >
                    <span className="text-[#0A1628] font-bold">{i + 1}</span>
                  </div>
                  <div
                    className={`flex-1 ${i % 2 === 0 ? "md:order-2 md:text-left" : "md:order-1 md:text-right"}`}
                  >
                    <div className="card-dark p-6">
                      <step.icon size={24} className="text-[#FF9933] mb-3" />
                      <h3 className="text-lg font-semibold text-[#F8FAFC] mb-2">
                        {step.title}
                      </h3>
                      <p className="text-[#94A3B8] text-sm">{step.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div
          className="max-w-2xl mx-auto text-center p-12 rounded-2xl"
          style={{
            background: "linear-gradient(135deg, rgba(255,153,51,0.05) 0%, rgba(19,136,8,0.05) 100%)",
            border: "1px solid rgba(255,153,51,0.1)",
          }}
        >
          <h2 className="text-3xl font-bold text-[#F8FAFC] mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-[#94A3B8] mb-8">
            Join thousands of citizens using Smart Bharat
          </p>
          <Link
            to="/chat"
            className="btn-saffron inline-flex items-center gap-2 text-lg px-8 py-4"
          >
            <Sparkles size={20} />
            Launch AI Assistant
          </Link>
        </div>
      </section>
    </div>
  );
}

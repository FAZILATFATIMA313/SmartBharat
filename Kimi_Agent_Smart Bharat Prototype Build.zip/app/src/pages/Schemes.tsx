import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useLanguage } from "@/hooks/useLanguage";
import {
  Search,
  ExternalLink,
  Bookmark,
  CheckCircle2,
  X,
  Stethoscope,
  Wheat,
  Landmark,
  HardHat,
  GraduationCap,
  Home,
  HeartHandshake,
  Briefcase,
  HelpCircle,
} from "lucide-react";
import type { ReactNode } from "react";

const categoryIcons: Record<string, ReactNode> = {
  healthcare: <Stethoscope size={16} />,
  agriculture: <Wheat size={16} />,
  "financial-inclusion": <Landmark size={16} />,
  infrastructure: <HardHat size={16} />,
  education: <GraduationCap size={16} />,
  housing: <Home size={16} />,
  "social-welfare": <HeartHandshake size={16} />,
  employment: <Briefcase size={16} />,
  other: <HelpCircle size={16} />,
};

const categoryColors: Record<string, string> = {
  healthcare: "#EF4444",
  agriculture: "#22C55E",
  "financial-inclusion": "#3B82F6",
  infrastructure: "#8B5CF6",
  education: "#F59E0B",
  housing: "#EC4899",
  "social-welfare": "#14B8A6",
  employment: "#6366F1",
  other: "#6B7280",
};

export default function Schemes() {
  const { t } = useLanguage();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [status, setStatus] = useState("all");
  const [page, setPage] = useState(1);
  const [selectedScheme, setSelectedScheme] = useState<number | null>(null);

  const { data, isLoading } = trpc.scheme.list.useQuery({
    search: search || undefined,
    category: category !== "all" ? category : undefined,
    status: status !== "all" ? status : undefined,
    page,
    limit: 12,
  });

  const categoriesQuery = trpc.scheme.categories.useQuery();
  const schemeDetail = trpc.scheme.getById.useQuery(
    { id: selectedScheme ?? 0 },
    { enabled: selectedScheme !== null }
  );

  const metrics = data?.schemes ?? [];
  const categories = categoriesQuery.data ?? [];

  const handleSearch = (value: string) => {
    setSearch(value);
    setPage(1);
  };

  return (
    <div className="pt-20 pb-16 px-4 min-h-screen">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-[#F8FAFC] mb-2">
            {t.schemes.title}
          </h1>
          <p className="text-[#94A3B8]">
            Discover and explore government schemes tailored for you
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search
              size={18}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-[#475569]"
            />
            <input
              type="text"
              value={search}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder={t.schemes.searchPlaceholder}
              className="input-dark pl-11 w-full"
            />
            {search && (
              <button
                onClick={() => handleSearch("")}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-[#475569] hover:text-[#F8FAFC]"
              >
                <X size={16} />
              </button>
            )}
          </div>

          <div className="flex gap-3">
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setPage(1);
              }}
              className="input-dark appearance-none cursor-pointer pr-8"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%2394A3B8' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E")`,
                backgroundRepeat: "no-repeat",
                backgroundPosition: "right 12px center",
              }}
            >
              <option value="all">{t.schemes.all}</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat.replace(/-/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                </option>
              ))}
            </select>

            <select
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(1);
              }}
              className="input-dark appearance-none cursor-pointer pr-8"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%2394A3B8' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E")`,
                backgroundRepeat: "no-repeat",
                backgroundPosition: "right 12px center",
              }}
            >
              <option value="all">{t.schemes.all}</option>
              <option value="active">{t.schemes.active}</option>
              <option value="upcoming">{t.schemes.upcoming}</option>
              <option value="expired">{t.schemes.expired}</option>
            </select>
          </div>
        </div>

        {/* Results count */}
        {data && (
          <p className="text-sm text-[#94A3B8] mb-4">
            Showing {metrics.length} of {data.total} schemes
          </p>
        )}

        {/* Schemes Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="card-dark h-64 animate-pulse" />
            ))}
          </div>
        ) : metrics.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-lg text-[#94A3B8]">{t.schemes.noResults}</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {metrics.map((scheme) => (
                <button
                  key={scheme.id}
                  onClick={() => setSelectedScheme(scheme.id)}
                  className="card-dark text-left w-full"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <span
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{
                        backgroundColor: `${categoryColors[scheme.category] ?? "#6B7280"}20`,
                        color: categoryColors[scheme.category] ?? "#6B7280",
                      }}
                    >
                      {categoryIcons[scheme.category] ?? <HelpCircle size={16} />}
                    </span>
                    <span
                      className="text-xs font-medium px-2 py-1 rounded-full capitalize"
                      style={{
                        backgroundColor: `${categoryColors[scheme.category] ?? "#6B7280"}15`,
                        color: categoryColors[scheme.category] ?? "#6B7280",
                      }}
                    >
                      {scheme.category.replace(/-/g, " ")}
                    </span>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ml-auto ${
                        scheme.status === "active"
                          ? "bg-green-500/10 text-green-400"
                          : scheme.status === "upcoming"
                          ? "bg-yellow-500/10 text-yellow-400"
                          : "bg-red-500/10 text-red-400"
                      }`}
                    >
                      {scheme.status}
                    </span>
                  </div>

                  <h3 className="text-lg font-semibold text-[#F8FAFC] mb-2 line-clamp-2">
                    {scheme.title}
                  </h3>

                  <p className="text-sm text-[#94A3B8] line-clamp-3 mb-4">
                    {scheme.content.substring(0, 200)}...
                  </p>

                  {(() => {
                    const metrics = scheme.metrics as Record<string, string> | null;
                    if (!metrics) return null;
                    return (
                      <div className="flex flex-wrap gap-2">
                        {Object.entries(metrics).slice(0, 3).map(([key, value]) => (
                          <span
                            key={key}
                            className="text-xs px-2 py-1 rounded bg-[#1A2A3F] text-[#E2E8F0]"
                          >
                            {key.replace(/_/g, " ")}: {value}
                          </span>
                        ))}
                      </div>
                    );
                  })()}
                </button>
              ))}
            </div>

            {/* Load More */}
            {data && page < data.totalPages && (
              <div className="text-center mt-8">
                <button
                  onClick={() => setPage((p) => p + 1)}
                  className="btn-outline"
                >
                  {t.schemes.loadMore}
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Scheme Detail Modal */}
      {selectedScheme !== null && schemeDetail.data && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          onClick={() => setSelectedScheme(null)}
        >
          <div
            className="bg-[#111D2E] rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto border border-[#1A2A3F]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="sticky top-0 bg-[#111D2E] border-b border-[#1A2A3F] p-6 flex items-start justify-between rounded-t-2xl">
              <div className="flex-1 pr-4">
                <div className="flex items-center gap-2 mb-2">
                  <span
                    className="text-xs font-medium px-2 py-1 rounded-full capitalize"
                    style={{
                      backgroundColor: `${categoryColors[schemeDetail.data.category] ?? "#6B7280"}15`,
                      color: categoryColors[schemeDetail.data.category] ?? "#6B7280",
                    }}
                  >
                    {schemeDetail.data.category.replace(/-/g, " ")}
                  </span>
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${
                      schemeDetail.data.status === "active"
                        ? "bg-green-500/10 text-green-400"
                        : schemeDetail.data.status === "upcoming"
                        ? "bg-yellow-500/10 text-yellow-400"
                        : "bg-red-500/10 text-red-400"
                    }`}
                  >
                    {schemeDetail.data.status}
                  </span>
                </div>
                <h2 className="text-xl font-bold text-[#F8FAFC]">
                  {schemeDetail.data.title}
                </h2>
              </div>
              <button
                onClick={() => setSelectedScheme(null)}
                className="flex-shrink-0 w-8 h-8 rounded-lg bg-[#1A2A3F] flex items-center justify-center text-[#94A3B8] hover:text-[#F8FAFC] transition-colors"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-[#FF9933] mb-2">About</h3>
                <p className="text-sm text-[#E2E8F0] leading-relaxed">
                  {schemeDetail.data.content}
                </p>
              </div>

              {schemeDetail.data.eligibility && (
                <div>
                  <h3 className="text-sm font-semibold text-[#FF9933] mb-2 flex items-center gap-2">
                    <CheckCircle2 size={16} />
                    {t.schemes.eligibility}
                  </h3>
                  <p className="text-sm text-[#E2E8F0]">
                    {schemeDetail.data.eligibility}
                  </p>
                </div>
              )}

              {schemeDetail.data.documents && (
                <div>
                  <h3 className="text-sm font-semibold text-[#FF9933] mb-2">
                    {t.schemes.documents}
                  </h3>
                  <p className="text-sm text-[#E2E8F0]">
                    {schemeDetail.data.documents}
                  </p>
                </div>
              )}

              {(() => {
                const metrics = schemeDetail.data.metrics as Record<string, string> | null;
                if (!metrics) return null;
                return (
                  <div>
                    <h3 className="text-sm font-semibold text-[#FF9933] mb-2">Key Metrics</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {Object.entries(metrics).map(([key, value]) => (
                        <div
                          key={key}
                          className="bg-[#0A1628] rounded-lg p-3 border border-[#1A2A3F]"
                        >
                          <p className="text-xs text-[#94A3B8] capitalize">
                            {key.replace(/_/g, " ")}
                          </p>
                          <p className="text-sm font-semibold text-[#F8FAFC]">
                            {value}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 bg-[#111D2E] border-t border-[#1A2A3F] p-6 flex gap-3 rounded-b-2xl">
              {schemeDetail.data.url && (
                <a
                  href={schemeDetail.data.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-saffron flex-1 flex items-center justify-center gap-2 text-sm"
                >
                  <ExternalLink size={16} />
                  {t.schemes.applyNow}
                </a>
              )}
              <button
                onClick={() => setSelectedScheme(null)}
                className="btn-outline flex items-center justify-center gap-2 text-sm"
              >
                <Bookmark size={16} />
                {t.schemes.saveForLater}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

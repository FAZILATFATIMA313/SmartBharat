import { useState, useRef, useEffect } from "react";
import { trpc } from "@/providers/trpc";
import { useLanguage } from "@/hooks/useLanguage";
import { AshokaChakra } from "@/components/AshokaChakra";
import {
  Send,
  Mic,
  Plus,
  MessageSquare,
  User,
  Bot,
  ChevronRight,
} from "lucide-react";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  sources?: Array<{
    id: number;
    title: string;
    category: string;
    url: string | null;
  }>;
}

export default function Chat() {
  const { t, language } = useLanguage();
  const [input, setInput] = useState("");
  const [sessionId, setSessionId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const createSession = trpc.chat.createSession.useMutation();
  const sendMessageMutation = trpc.chat.sendMessage.useMutation();
  const getMessages = trpc.chat.getMessages.useQuery(
    { sessionId: sessionId ?? 0 },
    { enabled: sessionId !== null }
  );
  const getSessions = trpc.chat.getSessions.useQuery();
  const utils = trpc.useUtils();

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // Initialize session
  const initSession = async () => {
    const session = await createSession.mutateAsync({ language: language as "en" | "hi" });
    setSessionId(session.id);
    setMessages([]);
  };

  // Load messages when session changes
  useEffect(() => {
    if (getMessages.data) {
      setMessages(
        getMessages.data.map((m) => ({
          id: m.id,
          role: m.role as "user" | "assistant",
          content: m.content,
          sources: m.sources ? (m.sources as Message["sources"]) : undefined,
        }))
      );
    }
  }, [getMessages.data]);

  // Start new chat on mount
  useEffect(() => {
    initSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSend = async () => {
    if (!input.trim() || !sessionId || isLoading) return;

    const userMessage = input.trim();
    setInput("");
    setIsLoading(true);

    // Optimistically add user message
    const tempId = Date.now();
    setMessages((prev) => [
      ...prev,
      { id: tempId, role: "user", content: userMessage },
    ]);

    try {
      const response = await sendMessageMutation.mutateAsync({
        sessionId,
        message: userMessage,
        language: language as "en" | "hi",
      });

      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempId),
        { id: tempId, role: "user", content: userMessage },
        {
          id: tempId + 1,
          role: "assistant",
          content: response.reply,
          sources: response.sources ?? [],
        },
      ]);

      utils.chat.getMessages.invalidate({ sessionId });
    } catch (error) {
      console.error("Chat error:", error);
      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempId),
        { id: tempId, role: "user", content: userMessage },
        {
          id: tempId + 1,
          role: "assistant",
          content:
            language === "hi"
              ? "Maaf kijiye, kuchh galat ho gaya. Kripya baad mein prayas karein."
              : "Sorry, something went wrong. Please try again.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const suggestedQueries = t.chat.suggestedQueries;

  const handleNewChat = () => {
    initSession();
    inputRef.current?.focus();
  };

  return (
    <div className="pt-16 h-screen flex">
      {/* Sidebar - Chat History */}
      <aside className="hidden lg:flex w-72 flex-col border-r border-[#1A2A3F] bg-[#0A1628]">
        <div className="p-4">
          <button
            onClick={handleNewChat}
            className="w-full flex items-center gap-2 px-4 py-3 rounded-lg border border-[#FF9933]/30 text-[#FF9933] hover:bg-[#FF9933]/10 transition-all"
          >
            <Plus size={18} />
            {t.chat.newChat}
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-4 pb-4">
          {getSessions.data && getSessions.data.length > 0 ? (
            <div className="space-y-1">
              {getSessions.data.map((session) => (
                <button
                  key={session.id}
                  onClick={() => setSessionId(session.id)}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-sm transition-all ${
                    sessionId === session.id
                      ? "bg-[#FF9933]/10 text-[#FF9933]"
                      : "text-[#94A3B8] hover:bg-[#111D2E] hover:text-[#E2E8F0]"
                  }`}
                >
                  <MessageSquare size={14} />
                  <span className="truncate flex-1">{session.title}</span>
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm text-[#475569] text-center mt-8">
              {t.chat.noHistory}
            </p>
          )}
        </div>
      </aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col bg-[#0A1628]">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-6">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-2xl bg-[#FF9933]/10 flex items-center justify-center mb-6">
                <Bot size={32} className="text-[#FF9933]" />
              </div>
              <h2 className="text-2xl font-bold text-[#F8FAFC] mb-2">
                {t.appName} AI
              </h2>
              <p className="text-[#94A3B8] mb-8">{t.chat.welcome}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg w-full">
                {suggestedQueries.map((query, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setInput(query);
                      inputRef.current?.focus();
                    }}
                    className="flex items-center gap-2 px-4 py-3 rounded-lg bg-[#111D2E] border border-[#1A2A3F] text-sm text-[#E2E8F0] hover:border-[#FF9933]/30 hover:bg-[#FF9933]/5 transition-all text-left"
                  >
                    <ChevronRight size={14} className="text-[#FF9933] flex-shrink-0" />
                    <span className="truncate">{query}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
                >
                  <div
                    className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                      msg.role === "user"
                        ? "bg-[#FF9933]"
                        : "bg-[#FF9933]/10"
                    }`}
                  >
                    {msg.role === "user" ? (
                      <User size={16} className="text-[#0A1628]" />
                    ) : (
                      <Bot size={16} className="text-[#FF9933]" />
                    )}
                  </div>

                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      msg.role === "user"
                        ? "bg-[#FF9933] text-[#0A1628]"
                        : "bg-[#111D2E] text-[#F8FAFC] border border-[#1A2A3F]"
                    }`}
                  >
                    <div className="whitespace-pre-wrap text-sm leading-relaxed">
                      {msg.content}
                    </div>

                    {msg.sources && msg.sources.length > 0 && (
                      <div className="mt-3 pt-3 border-t border-[#1A2A3F]">
                        <p className="text-xs text-[#94A3B8] mb-2">Sources:</p>
                        <div className="flex flex-wrap gap-2">
                          {msg.sources.map((source) => (
                            <a
                              key={source.id}
                              href={source.url ?? "#"}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs px-2 py-1 rounded bg-[#1A2A3F] text-[#3B82F6] hover:text-[#FF9933] transition-colors"
                            >
                              {source.title}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#FF9933]/10 flex items-center justify-center">
                    <Bot size={16} className="text-[#FF9933]" />
                  </div>
                  <div className="bg-[#111D2E] border border-[#1A2A3F] rounded-2xl px-4 py-3">
                    <div className="flex items-center gap-2">
                      <AshokaChakra size={20} animate />
                      <span className="text-sm text-[#94A3B8]">{t.chat.typing}</span>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="border-t border-[#1A2A3F] px-4 py-4">
          <div className="max-w-3xl mx-auto flex items-center gap-3">
            <button
              className="flex-shrink-0 w-10 h-10 rounded-full bg-[#111D2E] border border-[#1A2A3F] flex items-center justify-center text-[#94A3B8] hover:text-[#FF9933] hover:border-[#FF9933]/30 transition-all relative"
              title={t.common.comingSoon}
            >
              <Mic size={18} />
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#FF9933]" />
            </button>

            <div className="flex-1 flex items-center gap-2 bg-[#111D2E] border border-[#1A2A3F] rounded-full px-4 py-2 focus-within:border-[#FF9933]/50 transition-all">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={t.chat.placeholder}
                className="flex-1 bg-transparent text-sm text-[#F8FAFC] placeholder:text-[#475569] outline-none"
                disabled={isLoading}
              />
            </div>

            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="flex-shrink-0 w-10 h-10 rounded-full bg-[#FF9933] flex items-center justify-center text-[#0A1628] hover:shadow-[0_0_20px_rgba(255,153,51,0.3)] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

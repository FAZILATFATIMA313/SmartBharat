import { useState, useEffect } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/hooks/useLanguage";
import {
  User,
  Bookmark,
  Sparkles,
  Save,
  Edit3,
  Stethoscope,
  Wheat,
  Landmark,
  HardHat,
  GraduationCap,
  Home,
  HeartHandshake,
  Briefcase,
  HelpCircle,
} from "lucide-react";

const categoryIcons: Record<string, React.ReactNode> = {
  healthcare: <Stethoscope size={14} />,
  agriculture: <Wheat size={14} />,
  "financial-inclusion": <Landmark size={14} />,
  infrastructure: <HardHat size={14} />,
  education: <GraduationCap size={14} />,
  housing: <Home size={14} />,
  "social-welfare": <HeartHandshake size={14} />,
  employment: <Briefcase size={14} />,
  other: <HelpCircle size={14} />,
};

const categoryColors: Record<string, string> = {
  healthcare: "#EF4444",
  agriculture: "#22C55E",
  "financial-inclusion": "#3B82F6",
  infrastructure: "#8B5CF6",
  education: "#F59E0B",
  housing: "#EC4899",
  "social-welfare": "#14B8A6",
  employment: "#6366F1",
  other: "#6B7280",
};

export default function Profile() {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"info" | "saved" | "recommendations">("info");
  const [isEditing, setIsEditing] = useState(false);

  const profileQuery = trpc.profile.get.useQuery(undefined, {
    retry: false,
  });
  const recommendationsQuery = trpc.profile.getRecommendations.useQuery(undefined, {
    retry: false,
  });
  const savedSchemesQuery = trpc.savedScheme.list.useQuery(undefined, {
    retry: false,
  });
  const upsertProfile = trpc.profile.upsert.useMutation();
  const utils = trpc.useUtils();

  const [formData, setFormData] = useState({
    phone: "",
    location: "",
    preferredLanguage: "en" as "en" | "hi",
    age: "" as string,
    occupation: "" as string,
    incomeBracket: "" as string,
    category: "" as string,
  });

  useEffect(() => {
    if (profileQuery.data) {
      setFormData({
        phone: profileQuery.data.phone ?? "",
        location: profileQuery.data.location ?? "",
        preferredLanguage: (profileQuery.data.preferredLanguage ?? "en") as "en" | "hi",
        age: profileQuery.data.age?.toString() ?? "",
        occupation: profileQuery.data.occupation ?? "",
        incomeBracket: profileQuery.data.incomeBracket ?? "",
        category: profileQuery.data.category ?? "",
      });
    }
  }, [profileQuery.data]);

  const handleSave = async () => {
    await upsertProfile.mutateAsync({
      phone: formData.phone || undefined,
      location: formData.location || undefined,
      preferredLanguage: formData.preferredLanguage || undefined,
      age: formData.age ? parseInt(formData.age) : undefined,
      occupation: (formData.occupation as any) || undefined,
      incomeBracket: (formData.incomeBracket as any) || undefined,
      category: (formData.category as any) || undefined,
    });
    setIsEditing(false);
    utils.profile.get.invalidate();
    utils.profile.getRecommendations.invalidate();
  };

  const tabs = [
    { key: "info" as const, label: t.profile.personalInfo, icon: User },
    { key: "saved" as const, label: t.profile.savedSchemes, icon: Bookmark },
    { key: "recommendations" as const, label: t.profile.recommendations, icon: Sparkles },
  ];

  if (!user) {
    return (
      <div className="pt-20 pb-16 px-4 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <User size={48} className="text-[#475569] mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-[#F8FAFC] mb-2">Login Required</h2>
          <p className="text-[#94A3B8] mb-6">Please login to view your profile</p>
          <Link to="/login" className="btn-saffron">
            Login
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 pb-16 px-4 min-h-screen">
      <div className="max-w-4xl mx-auto">
        {/* Profile Header */}
        <div className="card-dark mb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-[#FF9933]/10 flex items-center justify-center">
              {user.avatar ? (
                <img
                  src={user.avatar}
                  alt={user.name ?? "User"}
                  className="w-16 h-16 rounded-full object-cover"
                />
              ) : (
                <User size={32} className="text-[#FF9933]" />
              )}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-[#F8FAFC]">
                {user.name ?? "User"}
              </h1>
              <p className="text-[#94A3B8]">{user.email ?? ""}</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-[#111D2E] rounded-xl mb-6 border border-[#1A2A3F] overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center justify-center gap-2 py-3 px-4 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                activeTab === tab.key
                  ? "bg-[#FF9933] text-[#0A1628]"
                  : "text-[#94A3B8] hover:text-[#F8FAFC]"
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Personal Info Tab */}
        {activeTab === "info" && (
          <div className="card-dark">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-[#F8FAFC]">
                {t.profile.personalInfo}
              </h2>
              <button
                onClick={() => {
                  if (isEditing) {
                    handleSave();
                  } else {
                    setIsEditing(true);
                  }
                }}
                disabled={upsertProfile.isPending}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#FF9933]/10 text-[#FF9933] hover:bg-[#FF9933]/20 transition-all disabled:opacity-50"
              >
                {isEditing ? (
                  <>
                    <Save size={16} />
                    {upsertProfile.isPending ? "Saving..." : t.profile.save}
                  </>
                ) : (
                  <>
                    <Edit3 size={16} />
                    {t.profile.editProfile}
                  </>
                )}
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm text-[#94A3B8] mb-1">
                  {t.profile.fields.phone}
                </label>
                {isEditing ? (
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="input-dark"
                  />
                ) : (
                  <p className="text-[#F8FAFC]">{profileQuery.data?.phone ?? "-"}</p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#94A3B8] mb-1">
                  {t.profile.fields.location}
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="input-dark"
                  />
                ) : (
                  <p className="text-[#F8FAFC]">{profileQuery.data?.location ?? "-"}</p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#94A3B8] mb-1">
                  {t.profile.fields.language}
                </label>
                {isEditing ? (
                  <select
                    value={formData.preferredLanguage}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        preferredLanguage: e.target.value as "en" | "hi",
                      })
                    }
                    className="input-dark"
                  >
                    <option value="en">English</option>
                    <option value="hi">Hindi</option>
                  </select>
                ) : (
                  <p className="text-[#F8FAFC] uppercase">
                    {profileQuery.data?.preferredLanguage ?? "en"}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#94A3B8] mb-1">
                  {t.profile.fields.age}
                </label>
                {isEditing ? (
                  <input
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                    className="input-dark"
                  />
                ) : (
                  <p className="text-[#F8FAFC]">{profileQuery.data?.age ?? "-"}</p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#94A3B8] mb-1">
                  {t.profile.fields.occupation}
                </label>
                {isEditing ? (
                  <select
                    value={formData.occupation}
                    onChange={(e) =>
                      setFormData({ ...formData, occupation: e.target.value })
                    }
                    className="input-dark"
                  >
                    <option value="">Select</option>
                    {Object.entries(t.profile.occupations).map(([key, label]) => (
                      <option key={key} value={key}>
                        {label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <p className="text-[#F8FAFC] capitalize">
                    {profileQuery.data?.occupation
                      ? t.profile.occupations[
                          profileQuery.data.occupation as keyof typeof t.profile.occupations
                        ]
                      : "-"}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#94A3B8] mb-1">
                  {t.profile.fields.incomeBracket}
                </label>
                {isEditing ? (
                  <select
                    value={formData.incomeBracket}
                    onChange={(e) =>
                      setFormData({ ...formData, incomeBracket: e.target.value })
                    }
                    className="input-dark"
                  >
                    <option value="">Select</option>
                    {Object.entries(t.profile.incomeBrackets).map(([key, label]) => (
                      <option key={key} value={key}>
                        {label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <p className="text-[#F8FAFC]">
                    {profileQuery.data?.incomeBracket
                      ? t.profile.incomeBrackets[
                          profileQuery.data.incomeBracket as keyof typeof t.profile.incomeBrackets
                        ]
                      : "-"}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm text-[#94A3B8] mb-1">
                  {t.profile.fields.category}
                </label>
                {isEditing ? (
                  <select
                    value={formData.category}
                    onChange={(e) =>
                      setFormData({ ...formData, category: e.target.value })
                    }
                    className="input-dark"
                  >
                    <option value="">Select</option>
                    {Object.entries(t.profile.categories).map(([key, label]) => (
                      <option key={key} value={key}>
                        {label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <p className="text-[#F8FAFC] uppercase">
                    {profileQuery.data?.category
                      ? t.profile.categories[
                          profileQuery.data.category as keyof typeof t.profile.categories
                        ]
                      : "-"}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Saved Schemes Tab */}
        {activeTab === "saved" && (
          <div>
            {savedSchemesQuery.data && savedSchemesQuery.data.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-4">
                {savedSchemesQuery.data.map((scheme) => (
                  <Link
                    key={scheme.id}
                    to="/schemes"
                    className="card-dark hover:border-[#FF9933]/30 transition-all"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span
                        className="w-6 h-6 rounded flex items-center justify-center"
                        style={{
                          backgroundColor: `${categoryColors[scheme.category] ?? "#6B7280"}20`,
                          color: categoryColors[scheme.category] ?? "#6B7280",
                        }}
                      >
                        {categoryIcons[scheme.category] ?? <HelpCircle size={12} />}
                      </span>
                      <span
                        className="text-xs font-medium px-2 py-0.5 rounded-full capitalize"
                        style={{
                          backgroundColor: `${categoryColors[scheme.category] ?? "#6B7280"}15`,
                          color: categoryColors[scheme.category] ?? "#6B7280",
                        }}
                      >
                        {scheme.category.replace(/-/g, " ")}
                      </span>
                    </div>
                    <h3 className="text-sm font-semibold text-[#F8FAFC] line-clamp-2">
                      {scheme.title}
                    </h3>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="card-dark text-center py-12">
                <Bookmark size={48} className="text-[#475569] mx-auto mb-4" />
                <p className="text-[#94A3B8]">No saved schemes yet</p>
                <Link
                  to="/schemes"
                  className="text-[#FF9933] hover:underline text-sm mt-2 inline-block"
                >
                  Explore schemes
                </Link>
              </div>
            )}
          </div>
        )}

        {/* Recommendations Tab */}
        {activeTab === "recommendations" && (
          <div>
            {recommendationsQuery.data && recommendationsQuery.data.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-4">
                {recommendationsQuery.data.map((scheme) => (
                  <Link
                    key={scheme.id}
                    to="/schemes"
                    className="card-dark hover:border-[#FF9933]/30 transition-all"
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <span
                        className="w-6 h-6 rounded flex items-center justify-center"
                        style={{
                          backgroundColor: `${categoryColors[scheme.category] ?? "#6B7280"}20`,
                          color: categoryColors[scheme.category] ?? "#6B7280",
                        }}
                      >
                        {categoryIcons[scheme.category] ?? <HelpCircle size={12} />}
                      </span>
                      <span
                        className="text-xs font-medium px-2 py-0.5 rounded-full capitalize"
                        style={{
                          backgroundColor: `${categoryColors[scheme.category] ?? "#6B7280"}15`,
                          color: categoryColors[scheme.category] ?? "#6B7280",
                        }}
                      >
                        {scheme.category.replace(/-/g, " ")}
                      </span>
                    </div>
                    <h3 className="text-sm font-semibold text-[#F8FAFC] line-clamp-2">
                      {scheme.title}
                    </h3>
                    <p className="text-xs text-[#94A3B8] mt-2 line-clamp-2">
                      {scheme.content.substring(0, 150)}...
                    </p>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="card-dark text-center py-12">
                <Sparkles size={48} className="text-[#475569] mx-auto mb-4" />
                <p className="text-[#94A3B8] mb-2">
                  Complete your profile to get personalized recommendations
                </p>
                <button
                  onClick={() => {
                    setActiveTab("info");
                    setIsEditing(true);
                  }}
                  className="text-[#FF9933] hover:underline text-sm"
                >
                  Update profile
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

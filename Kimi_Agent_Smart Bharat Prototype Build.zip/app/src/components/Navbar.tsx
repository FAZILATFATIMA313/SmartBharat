import { useState } from "react";
import { Link, useLocation } from "react-router";
import { Menu, X, Globe } from "lucide-react";
import { AshokaChakraSmall } from "./AshokaChakra";
import { useLanguage } from "@/hooks/useLanguage";
import { useAuth } from "@/hooks/useAuth";
import type { Language } from "@/lib/i18n";

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const { language, setLanguage, t } = useLanguage();
  const { user, logout } = useAuth();

  const navLinks = [
    { href: "/", label: t.nav.home },
    { href: "/chat", label: t.nav.chat },
    { href: "/schemes", label: t.nav.schemes },
    { href: "/complaints", label: t.nav.complaints },
  ];

  const isActive = (path: string) => location.pathname === path;

  const toggleLanguage = () => {
    setLanguage((prev: Language) => (prev === "en" ? "hi" : "en"));
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-[#0A1628]/80 border-b border-[#1A2A3F]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 group">
              <AshokaChakraSmall size={28} />
              <span className="text-lg font-bold text-[#F8FAFC] group-hover:text-[#FF9933] transition-colors">
                {t.appName}
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive(link.href)
                      ? "text-[#FF9933] bg-[#FF9933]/10"
                      : "text-[#E2E8F0] hover:text-[#FF9933] hover:bg-[#FF9933]/5"
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Right side */}
            <div className="flex items-center gap-2">
              {/* Language toggle */}
              <button
                onClick={toggleLanguage}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium text-[#E2E8F0] hover:text-[#FF9933] hover:bg-[#FF9933]/10 transition-all"
                title="Switch language"
              >
                <Globe size={16} />
                <span className="uppercase">{language}</span>
              </button>

              {/* Auth button */}
              {user ? (
                <div className="hidden md:flex items-center gap-2">
                  <Link
                    to="/profile"
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      isActive("/profile")
                        ? "text-[#FF9933] bg-[#FF9933]/10"
                        : "text-[#E2E8F0] hover:text-[#FF9933]"
                    }`}
                  >
                    {t.nav.profile}
                  </Link>
                  <button
                    onClick={logout}
                    className="px-4 py-2 rounded-lg text-sm font-medium text-[#E2E8F0] hover:text-white hover:bg-red-500/20 transition-all"
                  >
                    {t.nav.logout}
                  </button>
                </div>
              ) : (
                <Link
                  to="/login"
                  className="hidden md:block px-4 py-2 rounded-full text-sm font-semibold bg-[#FF9933] text-[#0A1628] hover:shadow-[0_0_20px_rgba(255,153,51,0.3)] transition-all"
                >
                  {t.nav.login}
                </Link>
              )}

              {/* Mobile menu button */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="md:hidden p-2 rounded-lg text-[#E2E8F0] hover:text-[#FF9933] hover:bg-[#FF9933]/10 transition-all"
              >
                {mobileOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-[#0A1628]/95 backdrop-blur-md md:hidden">
          <div className="flex flex-col items-center justify-center h-full gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                onClick={() => setMobileOpen(false)}
                className={`text-2xl font-semibold transition-colors ${
                  isActive(link.href) ? "text-[#FF9933]" : "text-[#F8FAFC] hover:text-[#FF9933]"
                }`}
              >
                {link.label}
              </Link>
            ))}
            {user ? (
              <>
                <Link
                  to="/profile"
                  onClick={() => setMobileOpen(false)}
                  className="text-2xl font-semibold text-[#F8FAFC] hover:text-[#FF9933] transition-colors"
                >
                  {t.nav.profile}
                </Link>
                <button
                  onClick={() => {
                    logout();
                    setMobileOpen(false);
                  }}
                  className="text-2xl font-semibold text-red-400 hover:text-red-300 transition-colors"
                >
                  {t.nav.logout}
                </button>
              </>
            ) : (
              <Link
                to="/login"
                onClick={() => setMobileOpen(false)}
                className="mt-4 px-8 py-3 rounded-full text-lg font-semibold bg-[#FF9933] text-[#0A1628]"
              >
                {t.nav.login}
              </Link>
            )}
          </div>
        </div>
      )}
    </>
  );
}

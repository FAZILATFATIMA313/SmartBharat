import { Link } from "react-router";
import { AshokaChakraSmall } from "./AshokaChakra";
import { useLanguage } from "@/hooks/useLanguage";
import { Mail, ExternalLink } from "lucide-react";

export function Footer() {
  const { t } = useLanguage();

  return (
    <footer className="bg-[#0A1628] border-t border-[#1A2A3F] mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <AshokaChakraSmall size={24} />
              <span className="text-lg font-bold text-[#F8FAFC]">{t.appName}</span>
            </Link>
            <p className="text-sm text-[#94A3B8]">{t.footer.tagline}</p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-[#F8FAFC] mb-4">{t.footer.quickLinks}</h3>
            <ul className="space-y-2">
              {[
                { href: "/", label: t.nav.home },
                { href: "/chat", label: t.nav.chat },
                { href: "/schemes", label: t.nav.schemes },
                { href: "/complaints", label: t.nav.complaints },
              ].map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="text-sm text-[#94A3B8] hover:text-[#FF9933] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="text-sm font-semibold text-[#F8FAFC] mb-4">{t.footer.resources}</h3>
            <ul className="space-y-2">
              <li>
                <span className="text-sm text-[#94A3B8]">About</span>
              </li>
              <li>
                <span className="text-sm text-[#94A3B8]">Help</span>
              </li>
              <li>
                <span className="text-sm text-[#94A3B8]">Privacy</span>
              </li>
              <li>
                <span className="text-sm text-[#94A3B8]">Terms</span>
              </li>
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h3 className="text-sm font-semibold text-[#F8FAFC] mb-4">{t.footer.connect}</h3>
            <div className="flex items-center gap-2 text-sm text-[#94A3B8]">
              <Mail size={16} />
              <span>support@smartbharat.in</span>
            </div>
            <a
              href="https://www.india.gov.in"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 mt-3 text-sm text-[#94A3B8] hover:text-[#FF9933] transition-colors"
            >
              <span>India Portal</span>
              <ExternalLink size={12} />
            </a>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-8 pt-8 border-t border-[#1A2A3F] text-center">
          <p className="text-sm text-[#94A3B8]">{t.footer.copyright}</p>
        </div>
      </div>
    </footer>
  );
}

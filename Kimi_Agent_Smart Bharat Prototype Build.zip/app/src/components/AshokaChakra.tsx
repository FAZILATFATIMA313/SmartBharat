interface AshokaChakraProps {
  size?: number;
  className?: string;
  animate?: boolean;
}

export function AshokaChakra({ size = 40, className = "", animate = true }: AshokaChakraProps) {
  const spokeCount = 24;
  const spokes = Array.from({ length: spokeCount }, (_, i) => {
    const angle = (i * 360) / spokeCount;
    return angle;
  });

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={`${animate ? "animate-spin-slow" : ""} ${className}`}
      style={{ filter: "drop-shadow(0 0 8px rgba(255,153,51,0.3))" }}
    >
      {/* Outer circle */}
      <circle
        cx="50"
        cy="50"
        r="48"
        fill="none"
        stroke="#FF9933"
        strokeWidth="1.5"
        opacity="0.6"
      />
      
      {/* Center hub */}
      <circle cx="50" cy="50" r="4" fill="#FF9933" />
      
      {/* Inner circle */}
      <circle
        cx="50"
        cy="50"
        r="8"
        fill="none"
        stroke="#FF9933"
        strokeWidth="1"
        opacity="0.4"
      />

      {/* Spokes */}
      {spokes.map((angle, i) => {
        const rad = (angle * Math.PI) / 180;
        const innerR = 8;
        const outerR = 44;
        const x1 = 50 + innerR * Math.cos(rad);
        const y1 = 50 + innerR * Math.sin(rad);
        const x2 = 50 + outerR * Math.cos(rad);
        const y2 = 50 + outerR * Math.sin(rad);

        return (
          <g key={i}>
            {/* Spoke line */}
            <line
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#FF9933"
              strokeWidth="1.2"
              strokeLinecap="round"
            />
            {/* Spoke head (small circle at tip) */}
            <circle
              cx={x2}
              cy={y2}
              r="1.5"
              fill="#FF9933"
            />
          </g>
        );
      })}
    </svg>
  );
}

export function AshokaChakraSmall({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <circle cx="50" cy="50" r="4" fill="#FF9933" />
      <circle cx="50" cy="50" r="46" fill="none" stroke="#FF9933" strokeWidth="2" />
      {Array.from({ length: 24 }, (_, i) => {
        const angle = (i * 360) / 24;
        const rad = (angle * Math.PI) / 180;
        return (
          <line
            key={i}
            x1={50 + 8 * Math.cos(rad)}
            y1={50 + 8 * Math.sin(rad)}
            x2={50 + 42 * Math.cos(rad)}
            y2={50 + 42 * Math.sin(rad)}
            stroke="#FF9933"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        );
      })}
    </svg>
  );
}
